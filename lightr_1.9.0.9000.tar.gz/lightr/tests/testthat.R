library(lightr) # nolint

if (requireNamespace("testthat", quietly = TRUE)) {
  library(testthat)
  test_check("lightr")
}
