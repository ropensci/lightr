# For snapshot tests, to avoid precision issues
options(digits = 5)
